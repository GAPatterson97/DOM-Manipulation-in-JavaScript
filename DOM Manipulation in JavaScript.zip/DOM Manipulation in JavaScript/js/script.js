// This function should retrieve all the project objects from projects array.
// It should then traverse over the array to create individual cards displaying each project details.
function loadProjects() {

  // Clear all projects from My Projects list to start
  document.getElementById("projects").innerHTML = null; 
  // Loop to retrieve all the cards from the projects array
  for(var i = 0; i < projects.length; i++) {
    let card = "<div class='card'><img src='" + projects[i].image + "'><span>" + projects[i].title + "</span><span>" + projects[i].description + "</span></div>"; //making one HTML card

    document.getElementById("projects").innerHTML += card; //add card to  div Element Id = "projects" --> ("My Projects")
  }
}


// This function should return the projectId of the new project
function newProjectId(){
  // Return the next new Project Id number from projects array
  return(projects.length + 1);
}

function saveNewProject() {
  // Get the new project details by using the DOM elements
  
  // Create the new projectId by calling the newProjectId() function
  let projectId = newProjectId()
  
  // Create a new project object
  projectObject = {
    "id": projectId,
    "title": document.getElementById("title").value,
    "description": document.getElementById("desc").value,
    "image": document.getElementById("image").value,
  };
  
  // Add the new project object to the projects array 
  projects.push(projectObject); // Add new project object to Array.

  // Display new projects Array after adding the new object to it
  console.log(projects);

  // Load the projects after adding the new project
  loadProjects();

  // Clear the values of the New Project Details Form after adding the new project
  document.getElementById("title").value = "";
  document.getElementById("desc").value = "";
  document.getElementById("image").value = "";
}
